export class AppAPi { 

    public ApiUrl: string = 'http://ubzil.com/api/';
    
    constructor() {
        

            
    }

    public  API_URL() {
        return this.ApiUrl
    }

}
