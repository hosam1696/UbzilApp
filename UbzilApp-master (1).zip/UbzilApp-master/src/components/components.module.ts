import { NgModule } from '@angular/core';
import { UzloaderComponent } from './uzloader/uzloader';
@NgModule({
	declarations: [UzloaderComponent],
	imports: [],
	exports: [UzloaderComponent]
})
export class ComponentsModule {}
