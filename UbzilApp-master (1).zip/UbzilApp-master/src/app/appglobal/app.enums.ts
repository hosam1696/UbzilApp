export enum EServicesCat {
    serviceRequest,
    bookDate,
    nearByServices
}

export enum EServicesImg {
    design,
    business,

}

export enum ICameraType {
       PHOTOLIBRARY = 0,
CAMERA,
     SAVEDPHOTOALBUM
}
